package com.example.demo.repositories;

import com.example.demo.model.artist;
import org.springframework.data.repository.CrudRepository;

public interface ArtistRepository extends CrudRepository<artist, Long> {
}
