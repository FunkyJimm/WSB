package com.example.demo.tools;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

@Component
public class DBInflater implements ApplicationListener<ContextRefreshedEvent> {

    private void initData() {
        //TODO: stworz 3 obiekty Song i Artist
        //TODO: powiaz powysze
        //TODO: zapisz do bazy z uzyciem repozytoriow
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
        initData();
    }
}
