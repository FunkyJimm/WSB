package com.example.demo.tools;

import com.example.demo.model.artist;
import com.example.demo.model.song;
import com.example.demo.repositories.ArtistRepository;
import com.example.demo.repositories.SongRepository;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

@Component
public class DBInflater implements ApplicationListener<ContextRefreshedEvent> {

    private ArtistRepository artistRepository;
    private SongRepository songRepository;

    public DBInflater(ArtistRepository artistRepository, SongRepository songRepository) {
        this.artistRepository = artistRepository;
        this.songRepository = songRepository;
    }

    private void initData() {
        artist john = new artist("John", "Frusciante", "Fru");
        song pastRecedes = new song("Past Recedes", "aternative", "060606", "2005", "Niandra");
        john.getSongs().add(pastRecedes);
        pastRecedes.getArtists().add(john);
        artistRepository.save(john);
        songRepository.save(pastRecedes);


        //TODO: stworz 3 obiekty Song i Artist
        //TODO: powiaz powysze
        //TODO: zapisz do bazy z uzyciem repozytoriow
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
        initData();
    }
}
